new Image().src = 'themes/default/img/loading.gif'; // preload animated gif
